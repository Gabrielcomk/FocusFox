function toggleChat() {
    const chat = document.getElementById("chatBox");
    chat.style.display = chat.style.display === "flex" ? "none" : "flex";
}

async function sendMessage() {
    const msgInput = document.getElementById("userMsg");
    const messages = document.getElementById("chatMessages");
    const msg = msgInput.value.trim();
    if (!msg) return;

    // Adiciona a mensagem do usuário
    messages.innerHTML += `<div><b>Você:</b> ${msg}</div>`;
    msgInput.value = "";

    try {
        // Envia a mensagem ao backend Spring Boot
        const response = await fetch("/api/home/mensagem", {
            method: "POST",
            headers: { "Content-Type": "text/plain" },
            body: msg
        });

        if (!response.ok) {
            throw new Error("Erro ao conectar ao servidor.");
        }

        const reply = await response.text();

        // Exibe a resposta do FoxBot
        messages.innerHTML += `<div><b>FoxBot:</b> ${reply}</div>`;
    } catch (error) {
        console.error(error);
        messages.innerHTML += `<div style="color:red;"><b>Erro:</b> Não consegui falar com o servidor 🦊💤</div>`;
    }

    // Faz o scroll automático para o final
    messages.scrollTop = messages.scrollHeight;
}
