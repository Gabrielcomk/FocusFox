package br.com.zaffari.FocusFox.source;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

public class ConexaoDB {

    private static final String CONNECTION_STRING =
            "mongodb+srv://XXXXXXXXXXXXXXXXXXXXXX/zaffari";

    // Cliente e database mantidos como estáticos únicos
    private static final MongoClient mongoClient = MongoClients.create(CONNECTION_STRING);
    private static final MongoDatabase db = mongoClient.getDatabase("zaffari");

    // Retorna a coleção desejada
    public static MongoCollection<Document> getCollection(String name) {
        try {
            return db.getCollection(name);
        } catch (Exception ex) {
            System.err.println("Erro na conexão com o MongoDB:");
            ex.printStackTrace();
            return null;
        }
    }
}
