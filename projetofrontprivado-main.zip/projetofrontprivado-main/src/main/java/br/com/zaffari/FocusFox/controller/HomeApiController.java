package br.com.zaffari.FocusFox.controller;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/home")
public class HomeApiController {

    @PostMapping("/mensagem")
    public String responder(@RequestBody String mensagemUsuario) {

        String msg = mensagemUsuario.toLowerCase();

        if (msg.contains("oi") || msg.contains("olá")) {
            return "Olá! 🦊 Eu sou o FoxBot! Pronto para te ajudar nos estudos?";
        } else if (msg.contains("vocabulary")) {
            return "A seção Vocabulary ajuda você a aprender novas palavras e expressões!";
        } else if (msg.contains("listening")) {
            return "Em Listening, você pode treinar sua compreensão auditiva com áudios e vídeos.";
        } else if (msg.contains("grammar") || msg.contains("gramática")) {
            return "Na aba Grammar, você aprende regras e estruturas do inglês!";
        } else if (msg.contains("tchau")) {
            return "Até mais! Continue estudando com foco! 🦊";
        } else {
            return "Desculpe, ainda não aprendi isso... tente perguntar sobre Vocabulary, Listening ou Grammar!";
        }
    }
}
