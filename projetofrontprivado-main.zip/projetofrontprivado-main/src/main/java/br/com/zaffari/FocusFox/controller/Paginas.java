package br.com.zaffari.FocusFox.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class Paginas {

    @GetMapping("/")
    public String index() {
        return "index"; // página inicial (pode ser login ou apresentação)
    }

    @GetMapping("/home")
    public String home() {
        return "home"; // renderiza o home.html no diretório /templates
    }
}
