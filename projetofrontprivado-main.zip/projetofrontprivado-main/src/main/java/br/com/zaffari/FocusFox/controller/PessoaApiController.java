package br.com.zaffari.FocusFox.controller;

import br.com.zaffari.FocusFox.model.Pessoa;
import br.com.zaffari.FocusFox.source.DAO;
import ch.qos.logback.core.model.Model;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;

@RestController
@RequestMapping("/api/pessoas")
public class PessoaApiController {

    @GetMapping
    public ResponseEntity<ArrayList<Pessoa>> listar() {
        ArrayList<Pessoa> list = DAO.listar();
        return ResponseEntity.ok(list);
    }



    @PostMapping
    public ResponseEntity<?> criar(@RequestBody Pessoa pessoa) {
        DAO.Insere(pessoa);
        return ResponseEntity.ok(pessoa);
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> atualizar(@PathVariable int id, @RequestBody Pessoa pessoa) {
        pessoa.setId(id);
        DAO.Atualiza(pessoa);
        return ResponseEntity.ok(pessoa);
    }


    @DeleteMapping("/{id}")
    public ResponseEntity<?> deletar(@PathVariable int id) {
        Pessoa p = new Pessoa(); p.setId(id);
        DAO.Exclui(p);
        return ResponseEntity.ok().build();
    }


}
