package br.com.zaffari.FocusFox.source;

import br.com.zaffari.FocusFox.model.Pessoa;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.FindOneAndUpdateOptions;
import com.mongodb.client.model.ReturnDocument;
import org.bson.Document;
import org.bson.conversions.Bson;

import java.util.ArrayList;
import java.util.List;

public class DAO {

    private static final String COLLECTION = "agendas";
    private static final String COUNTER_COLLECTION = "counters";

    private static int getNextId() {
        MongoCollection<Document> counters = ConexaoDB.getCollection(COUNTER_COLLECTION);

        Document result = counters.findOneAndUpdate(
                Filters.eq("_id", "agendas_id"),
                new Document("$inc", new Document("seq", 1)),
                new FindOneAndUpdateOptions().returnDocument(ReturnDocument.AFTER)
                        .upsert(true) // importante caso o contador não exista
        );

        if (result == null) {
            throw new RuntimeException("Erro ao gerar próximo ID!");
        }

        return result.getInteger("seq", 1);
    }

    public static ArrayList<Pessoa> listar() {
        ArrayList<Pessoa> pessoas = new ArrayList<>();

        try {
            MongoCollection<Document> collection = ConexaoDB.getCollection(COLLECTION);

            for (Document document : collection.find()) {
                Pessoa p = new Pessoa();
                p.setId(document.getInteger("id", 0));
                p.setNome(document.getString("nome"));
                p.setSenha(document.getString("senha"));
                pessoas.add(p);
            }

            System.out.println("Listagem concluída. Total: " + pessoas.size());

        } catch (Exception e) {
            System.err.println("Erro ao listar pessoas: " + e.getMessage());
            e.printStackTrace();
        }
        return pessoas;
    }

    public static void Insere(Pessoa pessoa) {
        try {
            MongoCollection<Document> collection = ConexaoDB.getCollection(COLLECTION);

            pessoa.setId(getNextId());

            Document doc = new Document("id", pessoa.getId())
                    .append("nome", pessoa.getNome())
                    .append("senha", pessoa.getSenha());

            collection.insertOne(doc);

            System.out.println("Pessoa inserida com sucesso: " + doc.toJson());

        } catch (Exception e) {
            System.err.println("Erro ao inserir pessoa: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public static void Exclui(Pessoa pessoa) {
        try {
            MongoCollection<Document> collection = ConexaoDB.getCollection(COLLECTION);

            collection.deleteOne(Filters.eq("id", pessoa.getId()));

            System.out.println("Excluído id=" + pessoa.getId());

        } catch (Exception e) {
            System.err.println("Erro ao excluir pessoa: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public static void Atualiza(Pessoa pessoa) {
        try {
            MongoCollection<Document> collection = ConexaoDB.getCollection(COLLECTION);

            Bson filtro = Filters.eq("id", pessoa.getId());
            Document atualizacao = new Document("$set",
                    new Document("nome", pessoa.getNome())
                            .append("senha", pessoa.getSenha())
            );

            collection.updateOne(filtro, atualizacao);

            System.out.println("Atualizado id=" + pessoa.getId());

        } catch (Exception e) {
            System.err.println("Erro ao atualizar pessoa: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
